import os

import bs4
import requests as requests
from flask import request
from urllib import request
from models import *
from exportExcelMarche import *

ndfRef = db.session.query(NoteDeFrais).filter(NoteDeFrais.acti_id == 0).all()
for n in ndfRef:
    print(n.type)
