import xlsxwriter
from xlsxwriter.utility import xl_col_to_name

from MyApp.models import *
from datetime import datetime
from flask import Flask, request


def export_excel_marcheMS4():
    moisDebut, anneeDebut = request.form['moisD'], request.form['anneeD']
    moisFin, anneeFin = request.form['moisF'], request.form['anneeF']
    workbook = xlsxwriter.Workbook('MarchéMS4-' + str(moisFin) + '-' + str(anneeFin) + '.xlsx')
    chronoBC = workbook.add_worksheet('chrono des BC')
    chronoBC.set_tab_color('#305496')
    chronoFD = workbook.add_worksheet('chrono des FD')
    chronoFD.set_tab_color('#305496')
    pdc = workbook.add_worksheet('PdC')
    pdc.set_tab_color('#305496')
    cra = workbook.add_worksheet('CRA Marché')
    cra.set_tab_color('#305496')
    """----- Format des titres -----"""
    format_titre = workbook.add_format()
    format_titre.set_font_color('#305496')
    format_titre.set_font_size(18)
    format_titre.set_italic()
    format_titre.set_underline()

    """----- Format écritures rouges -----"""
    format_font_rouge = workbook.add_format()
    format_font_rouge.set_font_color('red')
    format_font_rouge.set_font_size(18)

    """----- Format cases en-têtes -----"""
    format_entete = workbook.add_format()
    format_entete.set_font_color('white')
    format_entete.set_bold()
    format_entete.set_bg_color('#305496')
    format_entete.set_align('center')
    format_entete.set_border()

    """----- Format des formations et autres activités -----"""
    format_activite = workbook.add_format()
    format_activite.set_bg_color('#8EA9DB')
    format_activite.set_align('center')
    format_activite.set_border()

    """----- Format des bons de commande -----"""
    format_bon = workbook.add_format()
    format_bon.set_bg_color('#D9E1F2')
    format_bon.set_align('center')
    format_bon.set_border()

    """----- Format des activités finies -----"""
    format_fin = workbook.add_format()
    format_fin.set_bg_color('gray')
    format_fin.set_align('center')
    format_fin.set_border()

    """----- Format vert -----"""
    format_vert = workbook.add_format()
    format_vert.set_bg_color('#548235')
    format_vert.set_bold()
    format_vert.set_align('center')
    format_vert.set_border()

    """----- Format rouge -----"""
    format_rouge = workbook.add_format()
    format_rouge.set_bg_color('#FF2525')
    format_entete.set_font_color('white')
    format_rouge.set_bold()
    format_rouge.set_align('center')
    format_rouge.set_border()

    """----- Format des dates -----"""
    format_date = workbook.add_format({'num_format': 'd-mmm'})
    format_date.set_font_color('white')
    format_date.set_bold()
    format_date.set_bg_color('#305496')
    format_date.set_align('center')
    format_date.set_border()

    """ -------------------------------------- Feuille chronoBC ---------------------------------------------------- """
    # Que les parties Prod des BC
    boncomms = db.session.query(Boncomm).filter(Boncomm.nbJoursFormation == 0, Boncomm.nbJoursAutre == 0,
                                                Boncomm.nbCongesTot == 0, Boncomm.prodGdpOuFd == "Prod").all()
    data_boncomms = []
    for boncomm in boncomms:
        assocs = db.session.query(AssoUoBoncomm).filter(AssoUoBoncomm.boncomm_id == boncomm.id_acti).all()
        data_boncomms.append([boncomm, round(calculerTotUo(boncomm), 2), assocs])
    nbBons = len(data_boncomms)
    uos = db.session.query(UO).all()

    """ ---------- Format et tailles des cellules ---------- """
    """----- Taille lignes et colonnes -----"""
    chronoBC.set_column_pixels('A:A', 10)
    chronoBC.set_row_pixels(0, 10)
    chronoBC.set_column_pixels('D:D', 300)
    chronoBC.set_column_pixels('F:F', 72)
    chronoBC.set_column_pixels('G:G', 85)
    chronoBC.set_column_pixels('I:I', 80)
    chronoBC.set_column_pixels('J:J', 80)
    chronoBC.set_column_pixels('K:K', 80)
    chronoBC.set_column_pixels('L:L', 80)
    chronoBC.set_column_pixels('M:M', 80)

    """ ---------- Création des lignes ---------- """

    """----- Titre feuille -----"""
    chronoBC.write('B2', 'Chrono des bons de commande', format_titre)

    "----- En-têtes -----"
    chronoBC.write('B4', 'Projet', format_entete)
    chronoBC.write('C4', 'BC', format_entete)
    chronoBC.write('D4', 'Activité', format_entete)
    chronoBC.write('E4', 'Poste', format_entete)
    chronoBC.write('F4', 'Notif', format_entete)
    chronoBC.write('G4', 'Part ATOS', format_entete)
    chronoBC.write('H4', 'Part EGIS', format_entete)
    chronoBC.write('I4', 'Total', format_entete)
    chronoBC.write('J4', 'Date notif', format_entete)
    chronoBC.write('K4', 'Date début', format_entete)
    chronoBC.write('L4', 'Délais', format_entete)
    chronoBC.write('M4', 'Date fin', format_entete)
    chronoBC.write('N4', 'Fact', format_entete)
    chronoBC.write('P4', 'Total', format_bon)
    col = 16
    for uo in uos:
        chronoBC.set_column_pixels(xl_col_to_name(col) + ':' + xl_col_to_name(col), 60)
        chronoBC.write(xl_col_to_name(col) + '4', uo.num, format_entete)
        col += 1

    """----- Bons de commande -----"""
    row = 5
    for i in range(nbBons):
        assos = data_boncomms[i][0].uos
        chronoBC.write('B' + str(row), data_boncomms[i][0].projet, format_bon)
        chronoBC.write('C' + str(row), data_boncomms[i][0].num, format_bon)
        chronoBC.write('D' + str(row), data_boncomms[i][0].activite, format_bon)
        chronoBC.write('E' + str(row), data_boncomms[i][0].poste, format_bon)
        chronoBC.write('F' + str(row), data_boncomms[i][0].notification, format_bon)
        chronoBC.write('G' + str(row), data_boncomms[i][0].caAtos, format_bon)
        chronoBC.write('H' + str(row), data_boncomms[i][0].partEGIS, format_bon)
        chronoBC.write('I' + str(row), data_boncomms[i][0].montantHT, format_bon)
        chronoBC.write('J' + str(row), data_boncomms[i][0].dateNotif, format_bon)
        chronoBC.write('K' + str(row), data_boncomms[i][0].dateDebut, format_bon)
        chronoBC.write('L' + str(row), data_boncomms[i][0].delais, format_bon)
        chronoBC.write('M' + str(row), data_boncomms[i][0].dateFinOp, format_bon)
        chronoBC.write('N' + str(row), data_boncomms[i][0].facturation, format_bon)
        col = 16
        total = 0
        for asso in assos:
            total += asso.facteur * asso.uo.prix
            if asso.facteur != 0:
                chronoBC.write(xl_col_to_name(col) + str(row), asso.facteur, format_bon)
            else:
                chronoBC.write(xl_col_to_name(col) + str(row), "", format_bon)
            col += 1
        if round(data_boncomms[i][1], 2) == round(data_boncomms[i][0].montantHT, 2):
            chronoBC.write('P' + str(row), data_boncomms[i][1], format_activite)
        else:
            chronoBC.write('P' + str(row), data_boncomms[i][1], format_rouge)
        row += 1
    """--------------------------------------------------------------------------------------------------------------"""
    """ -------------------------------------- Feuille chronoFD ---------------------------------------------------- """
    # On ne montre que les FD
    boncomms = db.session.query(Boncomm).filter(Boncomm.prodGdpOuFd == "Fd", Boncomm.apm == "").all()
    data_fds = []
    for boncomm in boncomms:
        assocs = db.session.query(AssoUoBoncomm).filter(AssoUoBoncomm.boncomm_id == boncomm.id_acti).all()
        data_fds.append([boncomm, round(calculerTotUo(boncomm), 2), assocs])
    nbBons = len(data_fds)
    uos = db.session.query(UO).filter(UO.type == "Fd").all()  # Ne montre que les UO de type FD

    """ ---------- Format et tailles des cellules ---------- """
    """----- Taille lignes et colonnes -----"""
    chronoFD.set_column_pixels('A:A', 10)
    chronoFD.set_row_pixels(0, 10)
    chronoFD.set_column_pixels('D:D', 300)
    chronoFD.set_column_pixels('F:F', 72)
    chronoFD.set_column_pixels('G:G', 85)
    chronoFD.set_column_pixels('I:I', 80)
    chronoFD.set_column_pixels('J:J', 80)
    chronoFD.set_column_pixels('K:K', 80)
    chronoFD.set_column_pixels('L:L', 80)
    chronoFD.set_column_pixels('M:M', 80)

    """ ---------- Création des lignes ---------- """

    """----- Titre feuille -----"""
    chronoFD.write('B2', 'Chrono des frais de déplacement', format_titre)

    "----- En-têtes -----"
    chronoFD.write('B4', 'Projet', format_entete)
    chronoFD.write('C4', 'BC', format_entete)
    chronoFD.write('D4', 'Activité', format_entete)
    chronoFD.write('E4', 'Poste', format_entete)
    chronoFD.write('F4', 'Notif', format_entete)
    chronoFD.write('G4', 'Part ATOS', format_entete)
    chronoFD.write('H4', 'Part EGIS', format_entete)
    chronoFD.write('I4', 'Total', format_entete)
    chronoFD.write('J4', 'Date notif', format_entete)
    chronoFD.write('K4', 'Date début', format_entete)
    chronoFD.write('L4', 'Délais', format_entete)
    chronoFD.write('M4', 'Date fin', format_entete)
    chronoFD.write('N4', 'Fact', format_entete)
    chronoFD.write('P4', 'Total', format_bon)
    col = 16
    for uo in uos:
        chronoFD.set_column_pixels(xl_col_to_name(col) + ':' + xl_col_to_name(col), 60)
        chronoFD.write(xl_col_to_name(col) + '4', uo.num, format_entete)
        col += 1

    """----- Bons de commande -----"""
    row = 5
    for i in range(nbBons):
        assos = data_fds[i][0].uos
        chronoFD.write('B' + str(row), data_fds[i][0].projet, format_bon)
        chronoFD.write('C' + str(row), data_fds[i][0].num, format_bon)
        chronoFD.write('D' + str(row), data_fds[i][0].activite, format_bon)
        chronoFD.write('E' + str(row), data_fds[i][0].poste, format_bon)
        chronoFD.write('F' + str(row), data_fds[i][0].notification, format_bon)
        chronoFD.write('G' + str(row), data_fds[i][0].caAtos, format_bon)
        chronoFD.write('H' + str(row), data_fds[i][0].partEGIS, format_bon)
        chronoFD.write('I' + str(row), data_fds[i][0].montantHT, format_bon)
        chronoFD.write('J' + str(row), data_fds[i][0].dateNotif, format_bon)
        chronoFD.write('K' + str(row), data_fds[i][0].dateDebut, format_bon)
        chronoFD.write('L' + str(row), data_fds[i][0].delais, format_bon)
        chronoFD.write('M' + str(row), data_fds[i][0].dateFinOp, format_bon)
        chronoFD.write('N' + str(row), data_fds[i][0].facturation, format_bon)
        col = 16
        total = 0
        for asso in assos:
            if asso.uo.type == "Fd":
                total += asso.facteur * asso.uo.prix
                if asso.facteur != 0:
                    chronoFD.write(xl_col_to_name(col) + str(row), asso.facteur, format_bon)
                else:
                    chronoFD.write(xl_col_to_name(col) + str(row), "", format_bon)
                col += 1
        if round(data_fds[i][1], 2) == round(data_fds[i][0].montantHT, 2):
            chronoFD.write('P' + str(row), data_fds[i][1], format_activite)
        else:
            chronoFD.write('P' + str(row), data_fds[i][1], format_rouge)
        row += 1
    """--------------------------------------------------------------------------------------------------------------"""
    """ -------------------------------------- Feuille PdC ---------------------------------------------------- """
    moisDebut, anneeDebut = request.form['moisD'], request.form['anneeD']
    moisFin = request.form['moisF']
    anneeFin = request.form['anneeF']
    # On traite les différents cas, en fonction de l'année de début et fin
    if anneeDebut == anneeFin:
        moisToShow = [[int(moisDebut) + i, anneeDebut] for i in range(int(moisFin) - int(moisDebut) + 1)]
    else:
        moisToShow = [[int(moisDebut) + i, anneeDebut] for i in range(12 - int(moisDebut) + 1)]
        for i in range(int(anneeFin) - int(anneeDebut) - 1):
            for j in range(12):
                moisToShow.append([j + 1, int(anneeDebut) + i + 1])
        for j in range(int(moisFin)):
            moisToShow.append([j + 1, anneeFin])
    budgetTotJours = 0  # Budget total des projets, pour les calculs du 2ème et 3ème tableau
    nbMois = len(moisToShow)
    # Contiendra les données pour la création du 2ème et 3ème tableau
    dataTotMois = [[str(mois[0]) + "/" + str(mois[1]), 0.0, 0.0, 0.0] for mois in moisToShow]
    boncomms = db.session.query(Boncomm).filter(Boncomm.prodGdpOuFd == "Prod").all()
    projets = []  # Contiendra tous les différents projets en cours
    for boncomm in boncomms:
        projet = boncomm.projet
        if projet not in projets:
            projets.append(projet)
    data = []
    for projet in projets:
        # Si le projet est APPROCHES, on sépare entre EGIS et ATOS
        if projet == "APP":
            collabs = collabsProjet(projet)  # Récupère les collabs imputant sur ce projet
            bonsProjet = db.session.query(Boncomm).filter(Boncomm.prodGdpOuFd == "Prod", Boncomm.projet == projet).all()
            budgetTotAtos = 0
            budgetTotEgis = 0
            for bon in bonsProjet:
                budgetTotAtos += bon.caAtos
                budgetTotEgis += bon.partEGIS
                budgetTotJours += bon.caAtos + bon.partEGIS
            dataProjetAtos = [budgetTotAtos, projet + " Atos"]
            dataProjetEgis = [budgetTotEgis, projet + " EGIS"]

            for collab in collabs:
                # Si le collab est interne Atos, on ajoute ses données dans la part Atos :
                if collab.entreprise == "Atos":
                    dataCollab = [collab.abreviation(), collab, []]
                    joursAlloues = 0
                    assos = collab.boncomms
                    for asso in assos:
                        boncomm = asso.boncomm
                        if boncomm.projet == projet:
                            # Nombre total de jours alloués sur ce projet à ce collab :
                            joursAlloues += asso.joursAllouesBC
                            for i in range(nbMois):
                                mois = moisToShow[i]
                                consoMois = 0
                                dates = db.session.query(Date).filter(Date.mois == mois[0], Date.annee == mois[1]).all()
                                for date in dates:
                                    imp = db.session.query(Imputation).filter(Imputation.date_id == date.id_date,
                                                                              Imputation.collab_id == collab.id_collab,
                                                                              Imputation.acti_id == boncomm.id_acti,
                                                                              Imputation.type == "client").all()
                                    consoMois += imp[0].joursAllouesTache  # ce qu.'il à consommé sur ce mois
                                dataTotMois[i][1] += float(consoMois)
                                dataCollab[2].append(float(consoMois))
                elif collab.entreprise == "EGIS":  # Idem, mais dans le cas ou le collab vient d'EGIS
                    print("egis")
                    dataCollab = [collab.abreviation(), collab, []]
                    joursAlloues = 0
                    assos = collab.boncomms
                    for asso in assos:
                        boncomm = asso.boncomm
                        if boncomm.projet == projet and boncomm.prodGdpOuFd == "Prod":
                            joursAlloues += asso.joursAllouesBC
                            for i in range(nbMois):
                                mois = moisToShow[i]
                                consoMois = 0
                                dates = db.session.query(Date).filter(Date.mois == mois[0], Date.annee == mois[1]).all()
                                for date in dates:
                                    imp = db.session.query(Imputation).filter(Imputation.date_id == date.id_date,
                                                                              Imputation.collab_id == collab.id_collab,
                                                                              Imputation.acti_id == boncomm.id_acti,
                                                                              Imputation.type == "client").all()
                                    consoMois += imp[0].joursAllouesTache
                                dataTotMois[i][1] += float(consoMois)
                                dataCollab[2].append(float(consoMois))
                if joursAlloues != 0:
                    raf = joursAlloues - consoTotCollabProjet(projet, collab)
                    dataCollab.append(joursAlloues)
                    dataCollab.append(raf)
                    if collab.entreprise == "Atos":
                        dataProjetAtos.append(dataCollab)
                    elif collab.entreprise == "EGIS":
                        dataProjetEgis.append(dataCollab)
            data.append(dataProjetAtos)
            data.append(dataProjetEgis)

        else:  # Pour tous les autres projets, ATM1, ATM2, et ATM1-2 sont séparés, principe identique
            collabs = collabsProjet(projet)
            bonsProjet = db.session.query(Boncomm).filter(Boncomm.prodGdpOuFd == "Prod", Boncomm.projet == projet).all()
            budgetTot = 0
            for bon in bonsProjet:
                budgetTot += bon.caAtos
                budgetTotJours += bon.caAtos
            dataProjet = [budgetTot, projet]

            for collab in collabs:
                dataCollab = [collab.abreviation(), collab,[0 for i in range(nbMois)]]
                joursAlloues = 0
                assos = collab.boncomms
                for asso in assos:
                    boncomm = asso.boncomm
                    if boncomm.projet == projet and boncomm.prodGdpOuFd == "Prod":
                        joursAlloues += asso.joursAllouesBC
                        for i in range(nbMois):
                            mois = moisToShow[i]
                            consoMois = 0
                            dates = db.session.query(Date).filter(Date.mois == mois[0], Date.annee == mois[1]).all()
                            for date in dates:
                                imp = db.session.query(Imputation).filter(Imputation.date_id == date.id_date,
                                                                          Imputation.collab_id == collab.id_collab,
                                                                          Imputation.acti_id == boncomm.id_acti,
                                                                          Imputation.type == "client").all()
                                consoMois += imp[0].joursAllouesTache
                            dataTotMois[i][1] += float(consoMois)
                            dataCollab[2][i] += float(consoMois)
                if joursAlloues != 0:
                    raf = joursAlloues - consoTotCollabProjet(projet, collab)
                    dataCollab.append(joursAlloues)
                    dataCollab.append(raf)
                    dataProjet.append(dataCollab)

            data.append(dataProjet)
    budgetTotJours = budgetTotJours / 500  # Budget total en jour sur tous les projets
    if budgetTotJours != 0:
        dataTotMois[0][2] = round(100 * dataTotMois[0][1] / budgetTotJours, 1)
    else:
        dataTotMois[0][2] = 0
    # Remplissage des données nécessaires à la construction du 2ème et 3ème tableau :
    dataTotMois[0][3] = round(dataTotMois[0][1] / 18, 2)
    for i in range(nbMois - 1):
        # Production d'OTP moyen sur le mois :
        dataTotMois[i + 1][3] = round(dataTotMois[i + 1][1] / 18, 2)
        if budgetTotJours != 0:
            # Pourcentage d'avancement :
            dataTotMois[i + 1][2] = round((dataTotMois[i + 1][1] / budgetTotJours) * 100 + dataTotMois[i][2], 1)
        else:
            dataTotMois[i + 1][2] = 0
    """ ---------- Format et tailles des cellules ---------- """
    """----- Taille lignes et colonnes -----"""
    pdc.set_column_pixels('A:A', 10)
    pdc.set_row_pixels(0, 10)
    pdc.set_column_pixels('C:C', 90)
    pdc.set_column_pixels('D:D', 130)
    pdc.set_column_pixels('E:E', 90)
    pdc.set_column_pixels('F:F', 72)
    pdc.set_column_pixels('G:G', 85)
    pdc.set_column_pixels('I:I', 150)
    pdc.set_column_pixels('J:J', 80)
    pdc.set_column_pixels('K:K', 80)
    pdc.set_column_pixels('L:L', 80)
    pdc.set_column_pixels('M:M', 80)

    """ ---------- Création des lignes ---------- """

    """----- Titre feuille -----"""
    pdc.write('B2', 'Plan de charge', format_titre)
    if anneeDebut == anneeFin and moisDebut == moisFin:
        pdc.write('I2', str(moisDebut) + '/' + str(anneeDebut), format_font_rouge)
    else:
        pdc.write('I2', str(moisDebut) + '/' + str(anneeDebut) + ' - ' + str(moisFin) + '/' + str(anneeFin),
                  format_font_rouge)
    "----- En-têtes -----"
    pdc.write('C4', 'Budget HT', format_entete)
    pdc.write('D4', 'Nom', format_entete)
    pdc.write('E4', 'Prénom', format_entete)
    pdc.write('F4', 'Entreprise', format_entete)
    pdc.write('G4', 'Budget jour', format_entete)
    pdc.write('H4', 'RAF', format_entete)
    col = 9
    for mois in moisToShow:
        pdc.write(xl_col_to_name(col) + '4', str(mois[0]) + "/" + str(mois[1]), format_date)
        col += 1
    """----- Projet -----"""
    row = 5
    for projet in data:
        pdc.write('B' + str(row), projet[1], format_entete)
        pdc.write('C' + str(row), projet[0], format_bon)
        pdc.write('I' + str(row), "", format_activite)
        for collab in projet[2:]:
            if collab != projet[2]:
                pdc.write('C' + str(row), "", format_bon)
            pdc.write('I' + str(row), "", format_activite)
            print(collab, collab[0])
            pdc.write('D' + str(row), collab[1].nom, format_bon)
            pdc.write('E' + str(row), collab[1].prenom, format_bon)
            pdc.write('F' + str(row), collab[1].entreprise, format_bon)
            print(collab[2], collab[3])
            pdc.write('G' + str(row), collab[3], format_bon)
            pdc.write('H' + str(row), collab[4], format_bon)
            col = 9
            for i in range(len(moisToShow)):
                pdc.write(xl_col_to_name(col) + str(row), collab[2][i], format_bon)
                col += 1
            row += 1
        if collab != projet[-1]:
            row += 1

    """----- Tableaux avancement -----"""
    row += 2
    pdc.write('I' + str(row), "Conso du mois", format_entete)
    pdc.write('I' + str(row + 1), "Avancement", format_entete)
    pdc.write('I' + str(row + 2), "Prod OTP sur le mois", format_entete)

    col = 9
    for i in range(len(moisToShow)):
        pdc.write(xl_col_to_name(col) + str(row), dataTotMois[i][1], format_bon)
        pdc.write(xl_col_to_name(col) + str(row + 1), str(dataTotMois[i][2]) +' %', format_bon)
        pdc.write(xl_col_to_name(col) + str(row + 2), dataTotMois[i][3], format_bon)
        col += 1

    data = [dataTotMois[i][2] for i in range(len(dataTotMois))]
    graph = workbook.add_chart({'type': 'line'})
    graph.add_series({'values': '=PdC!$J$22:$' + xl_col_to_name(col) + '$22'})
    pdc.insert_chart('C' + str(row), graph)

    """--------------------------------------------------------------------------------------------------------------"""
    """------------------------------------------- Feuille CRA Marché -----------------------------------------------"""
    boncomms = db.session.query(Boncomm).filter(Boncomm.prodGdpOuFd == "Prod").all()
    projets = []  # Contiendra tous les différents projets en cours
    for boncomm in boncomms:
        projet = boncomm.projet
        if projet not in projets:
            projets.append(projet)

    dataBoncomms = [["CAUTRA"]]  # Regroupera ATM1, ATM2 et ATM1-2
    joursTotCautra = 0
    for projet in projets:
        if projet == "ATM1" or projet == "ATM2" or projet == "ATM1-2":
            dataBonProjet = dataBoncomms[0]
        else:
            if projet == "APP":
                dataBonProjet = ["APPROCHES"]
            elif projet == "TRANS":
                dataBonProjet = ["TRANSERVE"]
            else:
                dataBonProjet = [projet]
        # On va récupérer le nombre de jours total imputés sur ce projet :
        if projet == "ATM1" or projet == "ATM2" or projet == "ATM1-2":
            bonsProjet = db.session.query(Boncomm).filter(Boncomm.prodGdpOuFd == "Prod", Boncomm.projet == projet).all()
            for i in range(len(bonsProjet)):
                bon = bonsProjet[i]
                valeurs = valeursGlobales(bon)
                dataBonProjet.append([bon, valeurs[2]])  # Pourcentage d'avancement du bon
                joursTotCautra += valeurs[4]
        else:
            joursImput = 0
            bonsProjet = db.session.query(Boncomm).filter(Boncomm.prodGdpOuFd == "Prod", Boncomm.projet == projet).all()
            for i in range(len(bonsProjet)):
                bon = bonsProjet[i]
                valeurs = valeursGlobales(bon)
                dataBonProjet.append([bon, valeurs[2]])  # Pourcentage d'avancement du bon
                joursImput += valeurs[4]
            dataBonProjet[1].append(joursImput)
            for i in range(len(dataBonProjet) - 2):  # elt 0 est la str du projet
                dataBonProjet[i + 2].append(dataBonProjet[i + 1][2] - dataBonProjet[i + 1][0].jourThq)
            dataBoncomms.append(dataBonProjet)

    dataBoncomms[0][1].append(joursTotCautra)
    for i in range(len(dataBoncomms[0]) - 2):  # elt 0 est la str du projet
        dataBoncomms[0][i + 2].append(dataBoncomms[0][i + 1][2] - dataBoncomms[0][i + 1][0].jourThq)
    """ ---------- Format et tailles des cellules ---------- """
    """----- Taille lignes et colonnes -----"""
    cra.set_column_pixels('A:A', 10)
    cra.set_row_pixels(0, 10)
    cra.set_column_pixels('D:D', 350)
    cra.set_column_pixels('E:E', 80)
    cra.set_column_pixels('F:F', 115)
    cra.set_column_pixels('G:G', 90)
    cra.set_column_pixels('H:H', 90)
    cra.set_column_pixels('I:I', 150)
    cra.set_column_pixels('J:J', 150)
    cra.set_column_pixels('K:K', 80)
    cra.set_column_pixels('L:L', 80)
    cra.set_column_pixels('M:M', 80)

    """ ---------- Création des lignes ---------- """

    """----- Titre feuille -----"""
    cra.write('B2', 'CRA Marché', format_titre)

    "----- En-têtes -----"
    cra.write('B4', 'BC', format_entete)
    cra.write('C4', 'Poste', format_entete)
    cra.write('D4', 'Libellé du poste', format_entete)
    cra.write('E4', 'Date début', format_entete)
    cra.write('F4', 'Date fin contract.', format_entete)
    cra.write('G4', 'Date fin op.', format_entete)
    cra.write('H4', 'Avancement', format_entete)
    cra.write('I4', 'Jours alloués au bon', format_entete)
    cra.write('J4', 'Jours conso. tot. projet', format_entete)

    """----- Projet -----"""
    row = 5
    for projet in dataBoncomms:
        cra.write('E' + str(row), projet[0], format_activite)
        cra.write('B' + str(row), "", format_activite)
        cra.write('C' + str(row), "", format_activite)
        cra.write('D' + str(row), "", format_activite)
        cra.write('F' + str(row), "", format_activite)
        cra.write('G' + str(row), "", format_activite)
        cra.write('H' + str(row), "", format_activite)
        cra.write('I' + str(row), "", format_activite)
        cra.write('J' + str(row), "", format_activite)
        row += 1
        for bon in projet[1:]:
            cra.write('B' + str(row), bon[0].num, format_bon)
            cra.write('C' + str(row), bon[0].poste, format_bon)
            cra.write('D' + str(row), bon[0].activite, format_bon)
            cra.write('E' + str(row), bon[0].dateDebut, format_bon)
            cra.write('F' + str(row), bon[0].dateFinPrev, format_bon)
            cra.write('G' + str(row), bon[0].dateFinOp, format_bon)
            cra.write('H' + str(row), bon[1], format_bon)
            cra.write('I' + str(row), bon[0].jourThq, format_bon)
            cra.write('J' + str(row), bon[2], format_bon)
            row += 1

    """--------------------------------------------------------------------------------------------------------------"""
    workbook.close()
    return None
